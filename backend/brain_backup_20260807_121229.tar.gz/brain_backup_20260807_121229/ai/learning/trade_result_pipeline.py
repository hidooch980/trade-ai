from app.ai.journal.trade_journal import trade_journal
from app.learning.reward_engine import reward_engine
from app.ai.memory.adaptive_strategy_memory import adaptive_strategy_memory
from app.ai.learning.trade_learning_engine import trade_learning_engine


class TradeResultPipeline:

    def process(
        self,
        symbol,
        decision,
        entry_price,
        exit_price,
        volume,
        pnl,
        strategy="SMART_MONEY_M1"
    ):

        result = {
            "symbol": symbol,
            "decision": decision,
            "entry": entry_price,
            "exit": exit_price,
            "volume": volume,
            "profit": pnl,
            "status": "CLOSED"
        }

        reward = reward_engine.add_result(
            decision,
            pnl
        )

        memory = adaptive_strategy_memory.update(
            strategy,
            pnl
        )

        trade_learning_engine.record_trade(
            {
                "symbol": symbol,
                "decision": decision,
                "pnl": pnl
            }
        )

        history = trade_journal.history()

        history.append({
            "symbol": symbol,
            "decision": decision,
            "entry": entry_price,
            "exit": exit_price,
            "volume": volume,
            "profit": pnl,
            "status": "CLOSED"
        })

        trade_journal.file.write_text(
            __import__("json").dumps(
                history,
                indent=4
            )
        )

        return {
            "trade": result,
            "reward": reward,
            "memory": memory
        }


trade_result_pipeline = TradeResultPipeline()
