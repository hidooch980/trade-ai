from app.learning.market_memory import market_memory
from app.decision.confidence.confidence_engine import confidence_engine
from app.ai.memory.adaptive_strategy_memory import adaptive_strategy_memory


class FinalDecisionEngine:

    def decide(
        self,
        indicator_signal,
        ai_signal,
        risk,
        smart_money
    ):

        score = 0

        memory_weight = adaptive_strategy_memory.get_weight('SMART_MONEY_M1')
        score += (memory_weight.get('score',50)-50) * 0.2
        reasons = []
        reasons.append('ADAPTIVE_MEMORY_APPLIED')

        # Smart Money اصلی ترین وزن
        smart_score = smart_money.get("score", 0)

        score += smart_score * 0.6

        if smart_score > 0:
            reasons.append("SMART_MONEY_BULLISH")
        elif smart_score < 0:
            reasons.append("SMART_MONEY_BEARISH")


        # ساختار بازار
        trend = indicator_signal.get("trend")

        if trend == "BULLISH":
            score += 20
            reasons.append("BULLISH_STRUCTURE")

        elif trend == "BEARISH":
            score -= 20
            reasons.append("BEARISH_STRUCTURE")
        elif trend == "RANGE":
            reasons.append("RANGE_STRUCTURE")
        elif trend == "RANGE":
            reasons.append("RANGE_STRUCTURE")

        # Indicator Fusion score
        indicator_score = indicator_signal.get("score", 0)

        score += indicator_score * 0.5

        if indicator_score > 0:
            reasons.append("INDICATOR_FUSION_BULLISH")
        elif indicator_score < 0:
            reasons.append("INDICATOR_FUSION_BEARISH")


        # تایید AI
        ai_decision = ai_signal.get("decision")

        if ai_decision == "BUY":
            score += 10
            reasons.append("AI_CONFIRM_BUY")

        elif ai_decision == "SELL":
            score -= 10
            reasons.append("AI_CONFIRM_SELL")


        # ریسک
        if risk.get("approved"):
            reasons.append("RISK_OK")

        else:
            score = 0
            reasons.append("RISK_BLOCK")


        decision = "WAIT"

        if score >= 55:
            decision = "BUY"

        elif score <= -60:
            decision = "SELL"


        market_memory.add({
            "decision": decision,
            "score": score,
            "reasons": reasons,
            "indicator": indicator_signal,
            "ai": ai_signal,
            "risk": risk,
            "smart_money": smart_money
        })


        score = max(-100, min(100, score))

        confidence = confidence_engine.calculate(
            decision,
            score,
            smart_money,
            risk
        )

        if confidence.get("confidence", 0) > 100:
            confidence["confidence"] = 100

        if not confidence["trade_allowed"]:
            decision = "WAIT"
            reasons.append("LOW_CONFIDENCE_BLOCK")

        return {
            "engine": "FINAL_DECISION",
            "decision": decision,
            "score": score,
            "confidence": confidence,
            "reasons": reasons
        }
